import '../styles/global.css';

import React, { useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Link, useLocation } from 'react-router-dom';
import DarkModePage from './DarkModePage';
import LightModePage from './LightModePage';
import './App.css';

function App() {
  const location = useLocation();
  useEffect(() => {
    // Apply dark mode class if path is /dark-mode
    if (location.pathname === '/dark-mode') {
      document.body.classList.add('dark-mode');
      document.body.classList.remove('light-mode');
    } else {
      document.body.classList.add('light-mode');
      document.body.classList.remove('dark-mode');
    }
  }, [location.pathname]);

  return (
    <div className="App">
      <nav>
        <Link to="/dark-mode">
          <button className="dark-mode-button">Dark Mode</button>
        </Link>
        <Link to="/light-mode">
          <button className='light-mode-button'>Light Mode</button>
        </Link>
      </nav>

      <Routes>
        <Route path="/dark-mode" element={<DarkModePage />} />
        <Route path="/light-mode" element={<LightModePage />} />
      </Routes>
    </div>
  )
}
export default function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />;
}
