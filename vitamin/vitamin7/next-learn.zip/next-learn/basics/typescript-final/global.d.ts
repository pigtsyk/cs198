declare module 'remark-html' {
  const html: any;
  export default html;
}
