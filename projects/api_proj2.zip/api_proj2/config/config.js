module.exports = {
    YOUTUBE_API_KEY: '<Your_Youtube_API_Key>',
  };
  